#include "Scientist.hpp"

void Scientist::startResonanceCascade() {
    workplace.numberOfEmployees = 2;
}