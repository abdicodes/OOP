#include <iostream>
#include "AdvisorBotMain.h"
#include "CSVReader.h"
#include "HelpCommands.h"

int main()
{   
    AdvisorBotMain app{};
    app.init();


     
}
